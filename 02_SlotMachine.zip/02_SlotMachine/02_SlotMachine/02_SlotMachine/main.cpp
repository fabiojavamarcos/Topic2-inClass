//
//  main.cpp
//  02_SlotMachine
//
//  Created by Fabio Marcos De Abreu Santos on 9/26/23.
//

#include <iostream>
#include "SlotMachine.hpp"

int main() {

    SlotMachine ladyLuck;
    ladyLuck.pullLever();
    ladyLuck.display();
    while (!ladyLuck.isWinner()) {
        ladyLuck.pullLever();
        ladyLuck.display();
    }
    std::cout << "You won in " << ladyLuck.getSpinCt() << " spins!\n";

    return 0;
}
