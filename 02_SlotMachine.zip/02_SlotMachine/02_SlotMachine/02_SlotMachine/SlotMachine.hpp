//
//  SlotMachine.hpp
//  02_SlotMachine
//
//  Created by Fabio Marcos De Abreu Santos on 9/26/23.
//

#ifndef SlotMachine_hpp
#define SlotMachine_hpp

#include <stdio.h>

#endif /* SlotMachine_hpp */
#pragma once

#include <iostream>

class SlotMachine {
private:
    int reels[3];
    int numSymbols;
    int spinCt;
    void setNumSymbols(int);
    bool threeOfAKind()const;
    bool twoOfAKind()const;
    bool straight()const;

public:
    SlotMachine() { setNumSymbols(10); spinCt = 0; }
    SlotMachine(int numSymbols);
    int getNumSymbols()const;
    int getSpinCt()const;
    void pullLever();
    bool isWinner()const;
    void display()const;
};

